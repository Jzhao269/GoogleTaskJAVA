import java.util.Scanner; 
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
public class Scan
{
    int i = 0;
    ArrayList<String> library, name, id, hash;
    public Scan()
    {
        File file=new File("videos.txt");    
        library = new ArrayList<String>();
        name = new ArrayList<String>();
        id = new ArrayList<String>();
        hash = new ArrayList<String>();
        try
        {
            //creates a new file instance  
            FileReader fr=new FileReader(file);
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream  
            StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters  
            String line;
            while((line=br.readLine())!=null)  
            { 
                library.add(line); 
                String[] parts = line.split("[|]", 3);
                String firstPart = parts[0].trim(); 
                String secondPart = parts[1].trim();
                String thirdPart = ("["+ parts[2].trim() +"]"); 
                thirdPart = thirdPart.replace(",","");
                name.add(firstPart);
                id.add(secondPart);
                hash.add(thirdPart);
                i++;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        } 
    }

    public int Numberofvid()
    {
        return i;
    }
    
    public void PrintLibrary()
    {
        int x = 0;
        while (x < i)
        {
            System.out.println(name.get(i) + " (" + id.get(i) + ") " + hash.get(i));
            //System.out.println(library.get(x));
            x++;
        }
    }
}
