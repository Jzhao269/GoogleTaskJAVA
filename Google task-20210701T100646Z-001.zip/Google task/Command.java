import java.io.IOException;
import java.util.Random;
/**
 * Write a description of class Command here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Command
{
    String Instruction; 
    String Video; 
    Boolean playing = false; 
    Boolean pause = false; 
    Scan scan = new Scan();
    public Command()
    {
        
    }

    public void EnterCommand(String Instruction)
    {
        this.Instruction = Instruction;  
        String[] parts = Instruction.split(" ");
        String firstPart = parts[0];
        String secondPart = "";
        if (parts.length > 1)
        {
        secondPart = parts[1];
        }
        
        if (Instruction.equals("NUMBER_OF_VIDEOS"))
        {
            System.out.println(scan.Numberofvid()+" videos in the library");
        }
        
        else if (Instruction.equals("SHOW_ALL_VIDEOS"))
        {
            scan.PrintLibrary();
        }
        
        else if (Instruction.equals("SHOW_ALL_VIDEOS"))
        {
            scan.PrintLibrary();
        }
        
        else if (firstPart.equals("PLAY"))
        {
            int i = 0;
            Boolean matched = false;
            for (String id: scan.id)
            {
                if (id.equals(secondPart))
                {
                    if(playing)
                    {
                        System.out.println("Stopping video: "+Video);
                    }
                    matched = true;
                    System.out.println("Playing Video: "+ scan.name.get(i));
                    playing = true;
                    Video = scan.name.get(i);
                }
                i++;
            }
            
            if (!matched)
            {
                System.out.println("no such video");
            }
        }
        
        else if (Instruction.equals("STOP"))
        {
            if(playing)
                    {
                        System.out.println("Stopping video: "+Video);
                        playing = false;
                        Video = null;
                    }
            else
            {
                System.out.println("No video is currently playing");
            }
        }
        
        else if (Instruction.equals("PLAY_RANDOM"))
        {
            Random rand = new Random();
            int randomNum = rand.nextInt(((scan.Numberofvid()-1) - 0) + 1);
            if(playing)
                    {
                        System.out.println("Stopping video: "+Video);
                    }
             Video = scan.name.get(randomNum);
             System.out.println("Playing Video: "+ Video);
             playing = true;
        }
        
        else if (Instruction.equals("PAUSE"))
        {
            if(playing && !pause)
                    {
                        System.out.println("Pausing video: "+Video);
                        pause = true;
                    }
            else if(playing && pause)
                    {
                        System.out.println("Video already paused: "+Video);
                    }
            else
            {
                System.out.println("No video is currently playing");
            }
        }
        
        else if (Instruction.equals("CONTINUE"))
        {
            if(playing && !pause)
                    {
                        System.out.println("Video not paused");
                    }
            else if(playing && pause)
                    {
                        System.out.println("Continue Video: "+Video);
                        pause = false;
                    }
            else
            {
                System.out.println("No video is currently playing");
            }
        }
        
        else if (Instruction.equals("SHOW_PLAYING"))
        {
            if(playing)
            {
                    int pos = scan.name.indexOf(Video);
                    if (!pause)
                    {
                        System.out.println("Currently Playing: " + scan.name.get(pos) + " (" + scan.id.get(pos) + ") " + scan.hash.get(pos));
                    }
                    else if (pause)
                    {
                        System.out.println("Currently Playing: " + scan.name.get(pos) + " (" + scan.id.get(pos) + ") " + scan.hash.get(pos) + " - Paused");
                    }
            }
            else
            {
                System.out.println("No video is currently playing");
            }
        }
        
        else 
        {
            System.out.println("Error no action");
        }
    }
    
    public void test()
    {
        System.out.println(scan.hash);
    }
}
